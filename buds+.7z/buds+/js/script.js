// accordion
const accordion = document.getElementsByClassName('container');

for (i=0; i<accordion.length; i++) {
  accordion[i].addEventListener('click', function () {
    this.classList.toggle('active')
  })
}

// carousel
const buttonsWrapper = document.querySelector(".map");
const slides = document.querySelector(".inner");

buttonsWrapper.addEventListener("click", e => {
  if (e.target.nodeName === "BUTTON") {
    Array.from(buttonsWrapper.children).forEach(item =>
      item.classList.remove("active")
    );
    if (e.target.classList.contains("first")) {
      slides.style.transform = "translateX(-0%)";
      e.target.classList.add("active");
    } else if (e.target.classList.contains("second")) {
      slides.style.transform = "translateX(-32.38%)";
      e.target.classList.add("active");
    } else if (e.target.classList.contains('third')){
      slides.style.transform = 'translatex(-63.6666666667%)';
      e.target.classList.add('active');
    }
  }
});


// корзина
(function ($) {
  $(function () {


    $('.slider').slick({
      dots: true,
      nextArrow: '<i class="arrow arrow_next" aria-hidden="true"><img src="Images/Vector.png"></i>',
      prevArrow: '<i class="arrow arrow_prev" aria-hidden="true"><img src="Images/Vector.png"></i>',
      
      customPaging: function (slick, index) {
        var targetImage = slick.$slides.eq(index).find('img').attr('src');
        return '<img src=" ' + targetImage + ' "/>';
      }
    });


  });
})(jQuery);

// Корзина
    const buttonsBottom = document.querySelector(".dots");
const allSlides = document.querySelector(".slider_buy_container_items");

buttonsBottom.addEventListener("click", e => {
  if (e.target.nodeName === "BUTTON") {
    Array.from(buttonsBottom.children).forEach(item =>
      item.classList.remove("active")
    );
    if (e.target.classList.contains("dot_1")) {
      allSlides.style.transform = "translateX(-0%)";
      e.target.classList.add("active");
    } else if (e.target.classList.contains("dot_2")) {
      allSlides.style.transform = "translateX(-390px)";
      e.target.classList.add("active");
    } else if (e.target.classList.contains('dot_3')){
      allSlides.style.transform = 'translatex(-780px)';
      e.target.classList.add('active');
    }else if (e.target.classList.contains('dot_4')){
      allSlides.style.transform = 'translatex(-1170px)';
      e.target.classList.add('active');
    }

  }
});




// timer
document.addEventListener('DOMContentLoaded', () => {
  const newYear = new Date('Feb 23 2024 05:00:00:00');
  const milliseconds = newYear.getTime();

  const hoursVal = document.querySelector('.time-count__hours .time-count__val');
  const minutesVal = document.querySelector('.time-count__minutes .time-count__val');
  const secondsVal = document.querySelector('.time-count__seconds .time-count__val');
  const milisecondsVal = document.querySelector('.time-count__milisecond .time-count__val');

  const hoursText = document.querySelector('.time-count__hours .time-count__text');
  const minutesText = document.querySelector('.time-count__minutes .time-count__text');
  const secondsText = document.querySelector('.time-count__seconds .time-count__text');
  const milisecondsText = document.querySelector('.time-count__miliseconds .time-count__val');
  function declensionNum(num, words) {
    return words[(num % 100 > 4 && num % 100 < 20) ? 2 : [2, 0, 1, 1, 1, 2][(num % 10 < 5) ? num % 10 : 5]];
  }
  const timeCount = () => {
    let now = new Date();
    let leftUntil = newYear - now;
    let hours = Math.floor(leftUntil / 1000 / 60 / 60) % 24;
    let minutes = Math.floor(leftUntil / 1000 / 60) % 60;
    let seconds = Math.floor(leftUntil / 1000) % 60;
    var miliSeconds = Math.floor(leftUntil % 1000 / 100);
    Math.floor(leftUntil = leftUntil / 1000 | 0);

    hoursVal.textContent = hours.toString().padStart(2, '0') ;
    minutesVal.textContent = minutes.toString().padStart(2, '0');
    secondsVal.textContent = seconds.toString().padStart(2, '0');
    milisecondsVal.textContent = miliSeconds;
  };

  timeCount();
  setInterval(timeCount,10);
});


